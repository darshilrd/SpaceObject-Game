public struct Bitmasks {
    static let player: UInt32 = 1 << 1
    static let ship: UInt32 = 1 << 2
    static let uncrashedUfo: UInt32 = 1 << 3
}
